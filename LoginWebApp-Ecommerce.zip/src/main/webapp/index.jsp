<%
response.sendRedirect("products.jsp");
%>
